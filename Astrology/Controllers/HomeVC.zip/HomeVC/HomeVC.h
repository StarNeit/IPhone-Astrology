
#import <UIKit/UIKit.h>

@interface HomeVC : UIViewController{
    
}
@end
